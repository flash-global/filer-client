<?php

namespace Fei\Service\Filer\Client\Exception;

/**
 * Class FilerException
 *
 * @package Fei\Service\Filer\Client\Exception
 */
class FilerException extends \RuntimeException
{
}
